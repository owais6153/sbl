

<?php $__env->startSection('content'); ?>
	<div class="container">		
		<a href="<?php echo e(route('add_user')); ?>" class="btn btn-info mb-4">Create User</a>

		<a href="<?php echo e(route('logout')); ?>" class="btn btn-danger mb-4 ml-3">Logout</a>
		<?php if(session('success')): ?>
		    <div class="alert alert-success mb-3">
		        <?php echo e(session('success')); ?>

		    </div>
		<?php endif; ?>
		<table class="table table-striped">
		  <thead>
		    <tr>
		      <th scope="col">#</th>
		      <th scope="col">Name</th>
		      <th scope="col">Email</th>
		      <th scope="col">Actions</th>
		    </tr>
		  </thead>
		  <tbody>
		  	<?php if(empty(!$users)): ?>
		  		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    <tr>
				    	<td><?php echo e(($index + 1)); ?></td>
				    	<td><?php echo e($user->name); ?></td>
				    	<td><?php echo e($user->email); ?></td>
				    	<td>
				    		<?php if($user->id == 1 || Session::get('id') == $user->id): ?>
				    			No actions
				    		<?php else: ?> 
					    		<a href="<?php echo e(route('edit_user', ['id' => $user->id])); ?>">Edit</a>
					    		<a class="deleteIt" href="<?php echo e(route('deleteuser', ['id' => $user->id])); ?>">Delete</a>
				    		<?php endif; ?>
				    	</td>
				    </tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    <?php else: ?>
		    	<td colspan="4">No user found</td>	
		    <?php endif; ?>
		  </tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		$('.deleteIt').on('click', function(e){
			e.preventDefault();
			let result = confirm('Are you sure you want to delete?');
			if (result) {
				window.location.href = $(this).attr('href');
			}
		})
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\usercurd\resources\views/userlist.blade.php ENDPATH**/ ?>