

<?php $__env->startSection('content'); ?>
	<div class="container">
		<form class="row" action="<?php echo e(route('edituser')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<div class="col-md-6 mx-auto">
				<h1>Edit Users</h1>
				    <?php if(Session::get('danger')): ?> 
				    	<?php $__currentLoopData = Session::get('danger')[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    		<div class="alert alert-danger"><?php echo e($error); ?></div>
				    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    <?php endif; ?>
				<div class="form-group">
				    <label for="username">Name</label>
				    <input type="text" class="form-control" id="username" name="name" placeholder="Enter Name" value="<?php echo e($user->name); ?>">		   
					<input type="hidden" name="id" value="<?php echo e($user->id); ?>">
				  </div>
				  <div class="form-group">
				    <label for="email">Email address</label>
				    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter Email" name="email" value="<?php echo e($user->email); ?>">
				  </div>
				  <div class="form-group">
				    <label for="exampleInputPassword1">Password</label>
				    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password">
				  </div>
				  <button type="submit" class="btn btn-primary">Submit</button>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\usercurd\resources\views/edituser.blade.php ENDPATH**/ ?>